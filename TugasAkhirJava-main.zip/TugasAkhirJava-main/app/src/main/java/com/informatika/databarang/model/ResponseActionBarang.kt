package com.informatika.databarang.model

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ResponseActionBarang : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_response_action_barang)
    }
}