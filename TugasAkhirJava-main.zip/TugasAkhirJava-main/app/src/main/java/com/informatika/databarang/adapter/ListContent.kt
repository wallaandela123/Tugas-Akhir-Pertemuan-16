package com.informatika.databarang.adapter

class ListContent {
}