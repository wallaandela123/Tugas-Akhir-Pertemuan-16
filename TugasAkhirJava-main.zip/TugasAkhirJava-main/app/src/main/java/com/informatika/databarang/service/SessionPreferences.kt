package com.informatika.databarang.service

class SessionPreferences {
}